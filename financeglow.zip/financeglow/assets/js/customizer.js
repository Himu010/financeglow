(function ($) {
    
    wp.customize('footer_text', function (value) {
        value.bind(function (newval) {
            $('.bg-blue .container p.mb-0').text(newval + ' ' + new Date().getFullYear());
        });
    });
    
    wp.customize('site_description', function (value) {
        value.bind(function (newval) {
            $('.footer-header').next('p').text(newval);
        });
    });
    
    wp.customize('social_link_facebook', function(value) {
        value.bind(function(newval) {
            $('.facebook').attr('href', newval);
        });
    });
    wp.customize('social_link_twitter', function(value) {
        value.bind(function(newval) {
            $('.twitter').attr('href', newval);
        });
    });
    wp.customize('social_link_instagram', function(value) {
        value.bind(function(newval) {
            $('.instagram').attr('href', newval);
        });
    });
    wp.customize('social_link_linkedin', function(value) {
        value.bind(function(newval) {
            $('.linkedin').attr('href', newval);
        });
    });
    wp.customize('social_link_youtube', function(value) {
        value.bind(function(newval) {
            $('.youtube').attr('href', newval);
        });
    });
    
})(jQuery);
